dir2opt v0.6 - Generate RetroArch game options files from an options template file
               for each game in a directory scan.

with dir2opt [directory ...] [template]

Notes:
  [directory] should be the path to the games folder
  [template]  should be the template file containing the game options

Example:
              dir2opt "D:/ROMS/Atari - 2600" "template.opt"

Author:
   Discord - Romeo#3620