dir2opt v0.5 - Generate RetroArch game options files for each game from the
filenames in a directory scan.

with dir2opt [directory ...] [template]

Notes:
  [directory] should be the path to the games folder
  [template]  should be the template file containing the game options

Example:
              dir2opt "D:/ROMS/Atari - 2600" "template.opt"

Author:
   Discord - Romeo#3620
